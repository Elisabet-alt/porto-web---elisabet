const warnaAtas = "#1C1C1C"; 
const warnaBawah = "#E6E6FA "; 

document.body.style.background = `linear-gradient(to bottom, ${warnaAtas} , ${warnaBawah})`