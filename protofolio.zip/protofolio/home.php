<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warna di Ujung Kiri Atas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="colorful-text">Teks Berwarna di Ujung Kiri Atas</div>
</body>

<body>
    
</html>
